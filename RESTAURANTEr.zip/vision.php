
<?php
header('Content-Type: text/html; charset=UTF-8');
?>
<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
    </head>
    <body>
         <center><h3><font color="#5858FA"><b>VISIÓN</b></font></h3></center>
         <p class="rc">
             Ser reconocidos como el mejor restaurante de prestigio,
             confiable en comida marina y criolla en donde nuestro
             compromiso principal sea crear experiencias agradables
             al paladar de nuestros clientes.
         </p>
         <center><IMG src="imagenes/mosos.jpg" width="80%" height="400"/></center>>
 </body>
</html>