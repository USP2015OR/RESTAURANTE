
<?php
header('Content-Type: text/html; charset=UTF-8');
?>
<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
    </head>
    <body>
         <center><h3><font color="#5858FA"><b>MISIÓN</b></font></h3></center>
         <p class="rc">
             Ofrecer a nuestros clientes productos alimenticios de calidad, nutritivos
             y saludables; en un ambiente agradable desarrollados por un equipo humano
             competente, comprometido en proporcionar excelente servicio y satisfacción,
             generando desarrollo económico social al país y la empresa. 
         </p>
         <center><IMG src="imagenes/mosos.jpg" width="80%" height="400"/></center>>
 </body>
</html>