<?php
header('Content-Type: text/html; charset=UTF-8');
?>
<html>
    <head>
        <meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
    </head>
    <body>
         <center><h3><font color="#5858FA"><b>RESEÑA HISTORICA</b></font></h3></center>
         <p class="rc">
             El Restauran Turístico El R & R,
             es un restauran típico Chimbotano creado en el año 2000,
             por el Sr.Orbegoso Alayo Ricardo y Polonio Bocanegra Richard, quien lo consolido como una 
             empresa.En la actualidad puede disfrutar de la mejor comida del 
             Norte del Perú, en una arquitectura rústica y original, música, 
             artesanía y muchas cosa para pasar un día agradable con la familia. 
             Siguiendo el compromiso con nuestros principios, brindamos lo mejor 
             de nosotros para su entera satisfacción. Procuramos ser siempre una 
             empresa creativa, dinámica y diferente.
         </p>
         <center><IMG src="imagenes/res.jpg" width="80%" height="400"/></center>>
 </body>
</html>